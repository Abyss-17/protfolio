import React, { useEffect, useRef } from 'react';

const CustomCursor: React.FC = () => {
    const dotRef = useRef<HTMLDivElement>(null);
    const outlineRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const dot = dotRef.current;
        const outline = outlineRef.current;
        if (!dot || !outline) return;

        // Move cursor logic
        const onMouseMove = (e: MouseEvent) => {
            const posX = e.clientX;
            const posY = e.clientY;

            // Dot follows instantly
            dot.style.left = `${posX}px`;
            dot.style.top = `${posY}px`;

            // Outline follows with animation API for smoothness
            outline.animate({
                left: `${posX}px`,
                top: `${posY}px`
            }, { duration: 500, fill: "forwards" });
        };

        // Delegate hover checking
        const onHoverCheck = (e: MouseEvent) => {
            const target = e.target as HTMLElement;
            // Check if element or any parent has .hover-trigger
            if (target.closest('.hover-trigger') || target.tagName === 'A' || target.tagName === 'BUTTON') {
                document.body.classList.add("hovering");
            } else {
                document.body.classList.remove("hovering");
            }
        };

        window.addEventListener("mousemove", onMouseMove);
        window.addEventListener("mouseover", onHoverCheck);
        window.addEventListener("mouseout", onHoverCheck);

        return () => {
            window.removeEventListener("mousemove", onMouseMove);
            window.removeEventListener("mouseover", onHoverCheck);
            window.removeEventListener("mouseout", onHoverCheck);
        };
    }, []);

    return (
        <>
            <style>{`
                #cursor-dot, #cursor-outline {
                    position: fixed;
                    top: -100px; /* Initially off-screen */
                    left: -100px;
                    transform: translate(-50%, -50%);
                    border-radius: 50%;
                    z-index: 9999;
                    pointer-events: none;
                }

                #cursor-dot {
                    width: 8px; 
                    height: 8px;
                    background-color: #000;
                    transition: background-color 0.3s;
                }
                
                /* Dark Mode Support via body class */
                .dark #cursor-dot {
                    background-color: #fff;
                }

                #cursor-outline {
                    width: 40px; 
                    height: 40px;
                    border: 1px solid rgba(0, 0, 0, 0.5);
                    transition: width 0.2s, height 0.2s, background-color 0.2s, border-color 0.3s;
                }
                
                .dark #cursor-outline {
                    border-color: rgba(255, 255, 255, 0.5);
                }

                body.hovering #cursor-outline {
                    width: 80px; 
                    height: 80px;
                    background-color: rgba(255, 255, 255, 0.1);
                    border-color: transparent;
                    mix-blend-mode: difference;
                }
            `}</style>
            <div id="cursor-dot" ref={dotRef}></div>
            <div id="cursor-outline" ref={outlineRef}></div>
        </>
    );
};

export default CustomCursor;