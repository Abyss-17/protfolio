import React, { useEffect, useRef, useState, useLayoutEffect } from 'react';
import CustomCursor from './components/CustomCursor';
import ThreeBackground from './components/ThreeBackground';
import ThemeSwitch from './components/ThemeSwitch';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);
  // Default to light as per original design, but check storage
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const stored = localStorage.getItem('theme');
    return (stored as 'light' | 'dark') || 'light';
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Theme Toggle Logic
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  // Preloader Logic
  useLayoutEffect(() => {
    const gsap = window.gsap;
    if (!gsap) {
        setLoading(false); 
        return;
    }

    const tl = gsap.timeline({
        onComplete: () => setLoading(false)
    });

    tl.to("#loader-progress", {
        width: "100%",
        duration: 1.5,
        ease: "power2.inOut"
    })
    .to("#loader-name", {
        y: 0,
        duration: 1,
        ease: "power4.out"
    }, "-=0.5")
    .to("#loader-status", {
        opacity: 0,
        duration: 0.5
    })
    .to("#loader", {
        yPercent: -100,
        duration: 1.2,
        ease: "power4.inOut",
        delay: 0.2
    })
    .to(".hero-text", {
        y: 0,
        opacity: 1,
        stagger: 0.1,
        duration: 1,
        ease: "power3.out"
    }, "-=0.8");

  }, []);

  // Initialize Smooth Scroll & ScrollTrigger
  useEffect(() => {
    if (!loading && window.Lenis && window.ScrollTrigger && window.gsap) {
        const lenis = new window.Lenis({
            duration: 1.2,
            easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            smooth: true,
        });

        function raf(time: number) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);

        window.gsap.registerPlugin(window.ScrollTrigger);
        
        // Connect Lenis to ScrollTrigger
        lenis.on('scroll', window.ScrollTrigger.update);
        window.gsap.ticker.add((time: number) => {
            lenis.raf(time * 1000);
        });
        window.gsap.ticker.lagSmoothing(0);

        // Animations
        const gsap = window.gsap;
        const ScrollTrigger = window.ScrollTrigger;

        // Reveal Images
        gsap.utils.toArray('.reveal-wrap').forEach((wrap: any) => {
            let img = wrap.querySelector('.reveal-img');
            let overlay = wrap.querySelector('.reveal-overlay');
            
            let tl = gsap.timeline({
                scrollTrigger: {
                    trigger: wrap,
                    start: "top 80%",
                }
            });

            tl.to(overlay, {
                scaleY: 0,
                transformOrigin: "bottom",
                duration: 1,
                ease: "power3.inOut"
            })
            .to(img, {
                scale: 1,
                duration: 1.5,
                ease: "power3.out"
            }, "-=1");
        });

        // Cards Stagger
        gsap.from(".skill-card", {
            scrollTrigger: {
                trigger: "#expertise",
                start: "top 70%",
            },
            y: 100,
            opacity: 0,
            stagger: 0.1,
            duration: 0.8,
            ease: "back.out(1.7)"
        });
    }
  }, [loading]);

  return (
    <div className="relative font-sans text-primary dark:text-dark-text transition-colors duration-500">
      
      {/* LOADER */}
      <div id="loader" className="fixed inset-0 bg-black z-[10000] flex flex-col justify-center items-center text-white">
        <div className="font-serif text-[2rem] overflow-hidden">
            <div className="overflow-hidden">
                <span className="inline-block transform translate-y-full" id="loader-name">Jahin Abrar</span>
            </div>
        </div>
        <div className="w-[200px] h-[2px] bg-white/20 mt-5 relative overflow-hidden">
            <div className="absolute left-0 top-0 h-full bg-white w-0" id="loader-progress"></div>
        </div>
        <div className="mt-4 font-mono text-xs text-gray-400" id="loader-status">INITIALIZING SYSTEM...</div>
      </div>

      <CustomCursor />
      
      <ThemeSwitch theme={theme} toggleTheme={toggleTheme} />

      {/* NAVIGATION */}
      <nav className="fixed top-0 left-0 w-full z-50 px-8 py-6 flex justify-between items-center mix-blend-difference text-white transition-transform duration-500">
        <a href="#" className="text-2xl font-serif italic font-bold hover-trigger" data-cursor="Logo">
            JA<span className="text-xs font-sans not-italic ml-1 opacity-70">Bhuiyan</span>
        </a>
        
        <div className="hidden md:flex gap-10 font-mono text-xs tracking-widest uppercase">
            {['Profile', 'Expertise', 'System', 'Work', 'Contact'].map((item, idx) => (
                <a key={item} href={`#${item.toLowerCase() === 'profile' ? 'about' : item.toLowerCase()}`} className="hover:text-gray-400 transition-colors hover-trigger">
                    0{idx + 1}. {item}
                </a>
            ))}
        </div>

        <button className="md:hidden hover-trigger" onClick={() => setMobileMenuOpen(true)}>
            <i className="fas fa-bars text-xl"></i>
        </button>
      </nav>

      {/* MOBILE MENU */}
      <div className={`fixed inset-0 bg-black z-40 transform transition-transform duration-700 flex items-center justify-center ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <button className="absolute top-6 right-8 text-white text-2xl" onClick={() => setMobileMenuOpen(false)}>
            <i className="fas fa-times"></i>
        </button>
        <div className="flex flex-col gap-8 text-center font-serif text-4xl text-white">
             {['About', 'Expertise', 'System', 'Contact'].map(item => (
                 <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setMobileMenuOpen(false)} className="hover:text-gray-400 transition-colors">{item}</a>
             ))}
        </div>
      </div>

      <main ref={scrollRef} id="smooth-wrapper">
        
        {/* HERO SECTION */}
        <section className="relative h-screen-dvh flex flex-col justify-center items-start px-6 md:px-20 overflow-hidden">
            <ThreeBackground theme={theme} />

            <div className="relative z-10 max-w-5xl">
                <div className="overflow-hidden mb-4">
                    <p className="font-mono text-sm text-muted uppercase tracking-widest hero-text translate-y-full">
                        Pre-University Student & Developer
                    </p>
                </div>
                <div className="overflow-hidden">
                    <h1 className="text-6xl md:text-[8rem] leading-[0.9] font-serif text-primary dark:text-white mb-6 hero-text translate-y-full transition-colors duration-500">
                        Jahin <span className="italic text-gray-400 font-light">Abrar.</span>
                    </h1>
                </div>
                <div className="overflow-hidden max-w-2xl">
                    <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 leading-relaxed hero-text translate-y-full text-balance transition-colors duration-500">
                        Bridging the gap between <strong className="text-black dark:text-white">Technical Security</strong> and <strong className="text-black dark:text-white">Visual Creativity</strong>. 
                        Based in Dhaka, operating globally.
                    </p>
                </div>

                <div className="mt-12 flex flex-wrap gap-6 hero-text translate-y-full opacity-0">
                    <a href="#contact" className="group relative px-8 py-4 bg-black dark:bg-white dark:text-black text-white rounded-full overflow-hidden hover-trigger" data-cursor="Contact">
                        <div className="absolute inset-0 w-full h-full bg-gray-800 dark:bg-gray-200 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                        <span className="relative font-mono text-sm uppercase tracking-wider">Initiate Protocol</span>
                    </a>
                    <a href="#work" className="px-8 py-4 border border-gray-300 dark:border-gray-700 rounded-full font-mono text-sm uppercase tracking-wider hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all duration-300 hover-trigger">
                        View Documentation
                    </a>
                </div>
            </div>

            <div className="absolute bottom-10 right-10 md:right-20 flex flex-col items-center gap-2 animate-bounce">
                <span className="text-[10px] font-mono uppercase writing-vertical text-gray-400">Scroll Down</span>
                <i className="fas fa-arrow-down text-xs text-gray-400"></i>
            </div>
        </section>

        {/* MARQUEE */}
        <div className="py-8 bg-black dark:bg-white text-white dark:text-black border-y border-gray-800 dark:border-gray-200 overflow-hidden transition-colors duration-500">
            <style>{`
                 @keyframes scroll {
                    0% { transform: translateX(0); }
                    100% { transform: translateX(-50%); }
                }
                .marquee-content {
                    display: inline-block;
                    animation: scroll 30s linear infinite;
                }
            `}</style>
            <div className="whitespace-nowrap relative">
                <div className="marquee-content font-serif text-3xl italic flex items-center gap-12 opacity-50">
                    {Array(4).fill(
                        <>
                        <span>Penetration Testing</span> <i className="fas fa-asterisk text-xs"></i>
                        <span>Web Development</span> <i className="fas fa-asterisk text-xs"></i>
                        <span>Cloud Computing</span> <i className="fas fa-asterisk text-xs"></i>
                        <span>Graphic Design</span> <i className="fas fa-asterisk text-xs"></i>
                        </>
                    ).map((chunk, i) => <React.Fragment key={i}>{chunk}</React.Fragment>)}
                </div>
            </div>
        </div>

        {/* ABOUT */}
        <section id="about" className="py-[120px] px-6 md:px-20 bg-white dark:bg-dark-bg relative transition-colors duration-500">
            <div className="grid md:grid-cols-12 gap-16">
                <div className="md:col-span-5">
                    <div className="reveal-wrap aspect-[3/4] rounded-sm shadow-2xl relative overflow-hidden group">
                        <div className="reveal-overlay absolute top-0 left-0 w-full h-full bg-secondary dark:bg-dark-card z-[2]"></div>
                        <img src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1000&auto=format&fit=crop" 
                             alt="Profile" 
                             className="reveal-img w-full h-full object-cover transform scale-125 group-hover:scale-100 transition-transform duration-[1.5s] grayscale" />
                    </div>
                    
                    <div className="mt-8 grid grid-cols-2 gap-4">
                        <div className="p-4 bg-secondary dark:bg-dark-card rounded border border-gray-100 dark:border-gray-800 transition-colors">
                            <h3 className="text-3xl font-serif">5.0</h3>
                            <p className="text-xs font-mono text-muted uppercase mt-1">SSC GPA Score</p>
                            <p className="text-[10px] text-gray-400">KPB School & College</p>
                        </div>
                        <div className="p-4 bg-secondary dark:bg-dark-card rounded border border-gray-100 dark:border-gray-800 transition-colors">
                            <h3 className="text-3xl font-serif">HSC</h3>
                            <p className="text-xs font-mono text-muted uppercase mt-1">Candidate</p>
                            <p className="text-[10px] text-gray-400">Motijheel Govt. Boys</p>
                        </div>
                    </div>
                </div>

                <div className="md:col-span-7 flex flex-col justify-center">
                    <span className="font-mono text-xs text-accent dark:text-white uppercase tracking-widest mb-4 flex items-center gap-2">
                        <span className="w-8 h-[1px] bg-accent dark:bg-white"></span> About The Candidate
                    </span>
                    
                    <h2 className="text-4xl md:text-5xl font-serif leading-tight mb-8 dark:text-white">
                        Versatile thinker specializing in <span className="italic text-gray-400">Digital Security</span> & <span className="italic text-gray-400">Visual Arts</span>.
                    </h2>

                    <div className="space-y-6 text-gray-600 dark:text-gray-300 leading-relaxed">
                        <p>
                            I am MD. Jahin Abrar Bhuiyan, a versatile and dedicated Pre-University student with a passion for dismantling complex systems—whether that means breaking down code to find vulnerabilities or deconstructing visuals to create stunning designs.
                        </p>
                        <p>
                            Known for innovative thinking and strict punctuality, I thrive in environments that require a dual-brain approach: the logical precision of a <strong>Security Analyst</strong> and the aesthetic intuition of a <strong>Creative Designer</strong>.
                        </p>
                        <p>
                            Currently based in <strong>Bashabo, Dhaka</strong>, I am actively seeking to leverage my diverse skill set in a remote capacity, delivering high-quality work that merges functionality with form.
                        </p>
                    </div>

                    <div className="mt-12 pt-8 border-t border-gray-100 dark:border-gray-800 grid grid-cols-2 md:grid-cols-3 gap-8 font-mono text-xs">
                        <div>
                            <span className="block text-gray-400 mb-1">Location</span>
                            <span className="block text-black dark:text-white">Dhaka, Bangladesh</span>
                        </div>
                        <div>
                            <span className="block text-gray-400 mb-1">Email</span>
                            <a href="mailto:jahin.abrar.work@gmail.com" className="block text-black dark:text-white underline decoration-dotted">jahin.abrar.work@gmail.com</a>
                        </div>
                        <div>
                            <span className="block text-gray-400 mb-1">Availability</span>
                            <span className="block text-green-600 flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span> Remote Open
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        {/* EXPERTISE */}
        <section id="expertise" className="py-[120px] px-6 md:px-20 bg-secondary dark:bg-black transition-colors duration-500">
            <div className="max-w-7xl mx-auto">
                <div className="mb-20">
                    <span className="font-mono text-xs text-accent dark:text-white uppercase tracking-widest mb-2 block">02 // Expertise</span>
                    <h2 className="text-4xl md:text-6xl font-serif dark:text-white">Technical Arsenal</h2>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[
                        { icon: 'code', title: 'Web Management', desc: 'Full-stack development focusing on WordPress ecosystems.', list: ['WordPress Development', 'Front-end & Back-end', 'Performance Optimization'] },
                        { icon: 'user-secret', title: 'Security Analysis', desc: 'Identifying vulnerabilities through penetration testing and information gathering.', list: ['Penetration Testing', 'Info Gathering', 'Cloud Security'] },
                        { icon: 'pen-nib', title: 'Visual Design', desc: 'Creating compelling brand identities and visual documentation.', list: ['Logo Design', 'Adobe Illustrator', 'Photography'] },
                        { icon: 'cloud', title: 'Cloud & AI', desc: 'Leveraging Linux environments and AI to automate workflows.', list: ['Linux Administration', 'AI Utilization', 'Cloud Computing'] },
                        { icon: 'keyboard', title: 'Content Services', desc: 'High-speed typing and transcription services.', list: ['Content Transcription', 'Academic Preparation', 'MS Office Suite'] },
                        { icon: 'headphones', title: 'Multimedia', desc: 'Comprehensive audio and video editing capabilities.', list: ['Audio Editing', 'Photo Editing', 'Video Production'] }
                    ].map((skill, idx) => (
                        <div key={idx} className="skill-card p-8 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-dark-card group hover-trigger hover:shadow-xl dark:hover:shadow-gray-900 transition-all duration-300 transform hover:-translate-y-2" data-cursor={skill.title.split(' ')[0]}>
                            <div className="w-12 h-12 bg-black dark:bg-white text-white dark:text-black rounded-full flex items-center justify-center mb-6 text-xl group-hover:rotate-12 transition-transform">
                                <i className={`fas fa-${skill.icon}`}></i>
                            </div>
                            <h3 className="text-xl font-serif font-bold mb-3 dark:text-white">{skill.title}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 leading-relaxed">{skill.desc}</p>
                            <ul className="text-xs font-mono text-gray-400 space-y-2">
                                {skill.list.map((item, i) => <li key={i}>+ {item}</li>)}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>
        </section>

        {/* SYSTEM */}
        <section id="system" className="py-[120px] bg-black dark:bg-dark-card text-white relative overflow-hidden transition-colors duration-500">
             <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20 pointer-events-none">
                <div className="absolute top-20 -left-20 w-96 h-96 bg-blue-600 rounded-full blur-[120px]"></div>
                <div className="absolute bottom-20 -right-20 w-96 h-96 bg-purple-600 rounded-full blur-[120px]"></div>
            </div>

            <div className="max-w-7xl mx-auto relative z-10 px-6 md:px-20">
                <div className="flex flex-col md:flex-row justify-between items-end mb-20 border-b border-gray-800 pb-8">
                    <div>
                        <span className="font-mono text-xs text-gray-400 uppercase tracking-widest mb-2 block">03 // Hardware</span>
                        <h2 className="text-4xl md:text-6xl font-serif">System Architecture</h2>
                    </div>
                    <p className="max-w-md text-gray-400 text-sm mt-6 md:mt-0 text-right">
                        My workflow is powered by a dual-environment setup, optimized for both creative rendering and secure server operations.
                    </p>
                </div>

                <div className="grid md:grid-cols-2 gap-12">
                     <div className="bg-white/5 backdrop-blur-md p-8 rounded-2xl border border-white/10 hover:border-white/30 transition-all group">
                        <div className="flex justify-between items-start mb-8">
                            <i className="fab fa-windows text-4xl text-blue-400 group-hover:scale-110 transition-transform"></i>
                            <span className="px-3 py-1 bg-blue-500/20 text-blue-300 text-xs font-mono rounded-full border border-blue-500/30">PRIMARY STATION</span>
                        </div>
                        <h3 className="text-2xl font-bold mb-6">Physical System</h3>
                        <div className="space-y-4 font-mono text-sm text-gray-300">
                            {[
                                {k: 'CPU', v: 'Intel® Core™ i5-6402P'},
                                {k: 'Clock Speed', v: '2.80GHz (6th Gen)'},
                                {k: 'Memory', v: '8 GB RAM'},
                                {k: 'Usage', v: 'Creative Suite, Rendering'}
                            ].map((spec, i) => (
                                <div key={i} className="flex justify-between border-b border-white/5 pb-2">
                                    <span className="text-gray-500">{spec.k}</span>
                                    <span>{spec.v}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-white/5 backdrop-blur-md p-8 rounded-2xl border border-white/10 hover:border-white/30 transition-all group">
                        <div className="flex justify-between items-start mb-8">
                            <i className="fab fa-linux text-4xl text-yellow-400 group-hover:scale-110 transition-transform"></i>
                            <span className="px-3 py-1 bg-yellow-500/20 text-yellow-300 text-xs font-mono rounded-full border border-yellow-500/30">CLOUD SERVER</span>
                        </div>
                        <h3 className="text-2xl font-bold mb-6">Cloud Infrastructure</h3>
                        <div className="space-y-4 font-mono text-sm text-gray-300">
                             {[
                                {k: 'CPU', v: 'Intel® Xeon®'},
                                {k: 'Clock Speed', v: '2.20GHz'},
                                {k: 'Memory', v: '7.8 GB RAM'},
                                {k: 'Storage', v: '95 GB Total'}
                            ].map((spec, i) => (
                                <div key={i} className="flex justify-between border-b border-white/5 pb-2">
                                    <span className="text-gray-500">{spec.k}</span>
                                    <span>{spec.v}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>

        {/* WORK */}
        <section id="work" className="py-[120px] px-6 md:px-20 bg-white dark:bg-dark-bg transition-colors duration-500">
            <div className="max-w-7xl mx-auto">
                <div className="flex flex-col md:flex-row gap-12">
                    <div className="md:w-1/3">
                        <div className="sticky top-32">
                            <span className="font-mono text-xs text-accent dark:text-white uppercase tracking-widest mb-2 block">04 // Track Record</span>
                            <h2 className="text-4xl font-serif mb-6 dark:text-white">Selected Works</h2>
                            <p className="text-gray-500 mb-8 text-sm leading-relaxed">
                                A curation of projects spanning web development, brand identity, and academic resource management.
                            </p>
                            <a href="#contact" className="inline-flex items-center gap-2 text-sm font-bold border-b border-black dark:border-white pb-1 hover:text-gray-600 dark:hover:text-gray-300 dark:text-white">
                                Discuss a Project <i className="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>

                    <div className="md:w-2/3 space-y-12">
                        {[
                            { title: 'CMS Development', sub: 'Web Management', year: '2024', icon: 'wordpress', desc: 'Developed a fully functional website handling both front-end and back-end operations.' },
                            { title: 'Brand Identity Suite', sub: 'Logo & Financial Design', year: '2023', icon: 'vector-square', desc: 'Designed custom logos for various clients ensuring professional branding.' },
                            { title: 'Academic Resources', sub: 'Content & Transcription', year: 'Ongoing', icon: 'book', desc: 'Produced comprehensive coaching sheets containing over 100+ questions.' },
                        ].map((project, i) => (
                            <React.Fragment key={i}>
                                <div className="group hover-trigger" data-cursor="View">
                                    <div className="overflow-hidden rounded-lg mb-4 aspect-video bg-gray-100 dark:bg-dark-card relative">
                                        <div className="absolute inset-0 flex items-center justify-center bg-gray-200 dark:bg-gray-800 group-hover:bg-gray-300 dark:group-hover:bg-gray-700 transition-colors">
                                            <i className={`fas fa-${project.icon} text-6xl text-gray-400 dark:text-gray-500`}></i>
                                        </div>
                                    </div>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h3 className="text-2xl font-serif font-bold group-hover:text-gray-600 dark:group-hover:text-gray-400 transition-colors dark:text-white">{project.title}</h3>
                                            <p className="text-sm text-gray-500 mt-2">{project.sub}</p>
                                        </div>
                                        <span className="px-3 py-1 border border-gray-200 dark:border-gray-700 rounded-full text-xs font-mono dark:text-gray-300">{project.year}</span>
                                    </div>
                                    <p className="mt-4 text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{project.desc}</p>
                                </div>
                                {i < 2 && <div className="w-full h-[1px] bg-black/10 dark:bg-white/10 my-8"></div>}
                            </React.Fragment>
                        ))}
                    </div>
                </div>
            </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="py-32 px-6 md:px-20 bg-black dark:bg-dark-bg text-white relative overflow-hidden transition-colors duration-500">
            <div className="absolute inset-0 opacity-20" style={{backgroundImage: "url('https://grainy-gradients.vercel.app/noise.svg')"}}></div>
            <div className="max-w-4xl mx-auto text-center relative z-10">
                <span className="font-mono text-xs text-gray-500 uppercase tracking-widest mb-6 block">05 // Communication</span>
                <h2 className="text-5xl md:text-8xl font-serif mb-12 hover:text-gray-300 transition-colors duration-500 cursor-pointer">
                    Let's Talk.
                </h2>
                <div className="grid md:grid-cols-2 gap-8 text-left mb-16">
                    <div className="p-8 border border-white/10 rounded-xl bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-colors">
                        <h3 className="font-mono text-gray-400 text-xs mb-4 uppercase">Direct Line</h3>
                        <div className="flex flex-col gap-2">
                            <a href="tel:01712705200" className="text-2xl md:text-3xl font-bold hover:text-blue-400 transition-colors">017 1270 5200</a>
                            <a href="tel:01861144291" className="text-xl md:text-2xl text-gray-400 hover:text-blue-400 transition-colors">018 6114 4291</a>
                        </div>
                    </div>
                    <div className="p-8 border border-white/10 rounded-xl bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-colors">
                         <h3 className="font-mono text-gray-400 text-xs mb-4 uppercase">Digital Mail</h3>
                        <a href="mailto:jahin.abrar.work@gmail.com" className="text-2xl md:text-3xl font-bold hover:text-blue-400 transition-colors break-all">
                            jahin.abrar.work@<br/>gmail.com
                        </a>
                    </div>
                </div>
                <div className="flex justify-center gap-12 text-3xl">
                    <a href="#" className="hover:scale-125 transition-transform duration-300 hover:text-blue-500"><i className="fab fa-facebook"></i></a>
                    <a href="#" className="hover:scale-125 transition-transform duration-300 hover:text-pink-500"><i className="fab fa-instagram"></i></a>
                    <a href="#" className="hover:scale-125 transition-transform duration-300 hover:text-green-500"><i className="fab fa-whatsapp"></i></a>
                </div>
                <footer className="mt-24 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center text-xs font-mono text-gray-600">
                    <p>© 2025 MD. Jahin Abrar Bhuiyan. All Rights Reserved.</p>
                    <p className="mt-2 md:mt-0">Designed & Engineered in Dhaka.</p>
                </footer>
            </div>
        </section>

      </main>
    </div>
  );
};

export default App;