import React, { useEffect, useRef } from 'react';

const CustomCursor: React.FC = () => {
    const dotRef = useRef<HTMLDivElement>(null);
    const outlineRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const dot = dotRef.current;
        const outline = outlineRef.current;
        if (!dot || !outline) return;

        const onMouseMove = (e: MouseEvent) => {
            const posX = e.clientX;
            const posY = e.clientY;

            // Direct set for dot
            dot.style.left = `${posX}px`;
            dot.style.top = `${posY}px`;

            // Animation for outline
            outline.animate({
                left: `${posX}px`,
                top: `${posY}px`
            }, { duration: 500, fill: "forwards" });
        };

        const onMouseEnter = () => document.body.classList.add("hovering");
        const onMouseLeave = () => document.body.classList.remove("hovering");

        window.addEventListener("mousemove", onMouseMove);

        // Delegate event listeners for dynamic elements
        const addHoverListeners = () => {
            const triggers = document.querySelectorAll(".hover-trigger");
            triggers.forEach(trigger => {
                trigger.addEventListener("mouseenter", onMouseEnter);
                trigger.addEventListener("mouseleave", onMouseLeave);
            });
        };

        // Run once on mount
        addHoverListeners();
        
        // Re-run occasionally or observe DOM (simplified here)
        const interval = setInterval(addHoverListeners, 1000);

        return () => {
            window.removeEventListener("mousemove", onMouseMove);
            clearInterval(interval);
            const triggers = document.querySelectorAll(".hover-trigger");
            triggers.forEach(trigger => {
                trigger.removeEventListener("mouseenter", onMouseEnter);
                trigger.removeEventListener("mouseleave", onMouseLeave);
            });
        };
    }, []);

    return (
        <>
            <style>{`
                #cursor-dot, #cursor-outline {
                    position: fixed;
                    top: -100px; 
                    left: -100px;
                    transform: translate(-50%, -50%);
                    border-radius: 50%;
                    z-index: 9999;
                    pointer-events: none;
                }
                #cursor-dot {
                    width: 8px; height: 8px;
                    background-color: var(--cursor-color, #000);
                }
                .dark #cursor-dot {
                    background-color: #fff;
                }
                #cursor-outline {
                    width: 40px; height: 40px;
                    border: 1px solid rgba(0,0,0,0.5);
                    transition: width 0.2s, height 0.2s, background-color 0.2s;
                }
                .dark #cursor-outline {
                    border-color: rgba(255,255,255,0.5);
                }
                body.hovering #cursor-outline {
                    width: 80px; height: 80px;
                    background-color: rgba(255, 255, 255, 0.1);
                    border-color: transparent;
                    backdrop-filter: blur(2px);
                    mix-blend-mode: difference;
                }
            `}</style>
            <div id="cursor-dot" ref={dotRef}></div>
            <div id="cursor-outline" ref={outlineRef}></div>
        </>
    );
};

export default CustomCursor;