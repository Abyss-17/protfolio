import React, { useEffect, useRef } from 'react';

const ThreeBackground: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const materialRef = useRef<any>(null);

    useEffect(() => {
        if (!containerRef.current || !window.THREE) return;

        const THREE = window.THREE;
        const container = containerRef.current;
        const scene = new THREE.Scene();
        // Fog logic handled in animation loop or update
        
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        container.appendChild(renderer.domElement);

        const geometry = new THREE.BufferGeometry();
        const particlesCount = 700;
        const posArray = new Float32Array(particlesCount * 3);

        for(let i = 0; i < particlesCount * 3; i++) {
            posArray[i] = (Math.random() - 0.5) * 15;
        }

        geometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));

        const material = new THREE.PointsMaterial({
            size: 0.02,
            color: theme === 'dark' ? 0xffffff : 0x1a1a1a,
            transparent: true,
            opacity: 0.8,
        });
        materialRef.current = material;

        const particlesMesh = new THREE.Points(geometry, material);
        scene.add(particlesMesh);

        camera.position.z = 2;

        let mouseX = 0;
        let mouseY = 0;

        const handleMouseMove = (event: MouseEvent) => {
            mouseX = event.clientX / window.innerWidth - 0.5;
            mouseY = event.clientY / window.innerHeight - 0.5;
        };
        document.addEventListener('mousemove', handleMouseMove);

        const clock = new THREE.Clock();
        let animationId: number;

        const animate = () => {
            const elapsedTime = clock.getElapsedTime();
            particlesMesh.rotation.y = elapsedTime * 0.05;
            particlesMesh.rotation.x = mouseY * 0.5;
            particlesMesh.rotation.y += mouseX * 0.5;
            renderer.render(scene, camera);
            animationId = requestAnimationFrame(animate);
        };

        animate();

        const handleResize = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        };
        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
            document.removeEventListener('mousemove', handleMouseMove);
            cancelAnimationFrame(animationId);
            if (container) container.removeChild(renderer.domElement);
            geometry.dispose();
            material.dispose();
        };
    }, []);

    // Update material color when theme changes
    useEffect(() => {
        if (materialRef.current) {
            materialRef.current.color.setHex(theme === 'dark' ? 0xffffff : 0x1a1a1a);
        }
    }, [theme]);

    return (
        <div 
            ref={containerRef} 
            id="canvas-container" 
            className="absolute top-0 left-0 w-full h-screen z-0 opacity-60 pointer-events-auto"
        />
    );
};

export default ThreeBackground;