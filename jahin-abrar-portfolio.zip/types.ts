export interface NavLink {
  href: string;
  label: string;
}

export type Theme = 'light' | 'dark';

declare global {
  interface Window {
    gsap: any;
    ScrollTrigger: any;
    THREE: any;
    Lenis: any;
  }
}